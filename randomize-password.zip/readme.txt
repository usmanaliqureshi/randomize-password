=== Randomize Password ===
Contributors: usmanaliqureshi
Tags: security, password, random, wordpress, generate password, random password
Requires at least: 3.0
Tested up to: 4.8
Stable tag: 4.7.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

This plugin will help you to change the password for users depending on the schedule in settings (only set by administrators) of the plugin. It will add a new option on the profile page of each user to activate the schedule to randomly change their password.

== Screenshots ==

1. Option for each user on user settings page and profile page.

2. Randomize Password Settings page in Dashboard → Settings.

== Changelog ==

= 1.0.0 =

* Initial Release
