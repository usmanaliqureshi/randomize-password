<?php

/* Speech is silver but Silence is always golden */

?>